package com.cg.billing.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
@SessionAttributes("customerId")
public class BillingServicesController {

	@Autowired
	private BillingServices services;
	
	//Done
	@RequestMapping("/registerCustomerService")
	public ModelAndView registerCustomer(@Valid@ModelAttribute Customer customer, BindingResult result) {
		if(result.hasErrors()) return new ModelAndView("registrationPage"); 
		customer = services.acceptCustomerDetails(customer);
		return new ModelAndView("registrationSuccessPage", "customer", customer);
	}
	
	//Done
	@RequestMapping("/openAccountService")
	public ModelAndView openAccount(@SessionAttribute("customerId") int customerId , @RequestParam int planId) throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		long mobileNo = services.openPostpaidMobileAccount(customerId, planId);
		return new ModelAndView("openAccountPage", "mobileNo", mobileNo);
	}
	
	@RequestMapping("/mobileBillService")
	public ModelAndView getMonthlyBill(@SessionAttribute("customerId") int customerId, @RequestParam long mobileNo, @RequestParam String billMonth) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException {
		Bill bill = services.getMobileBillDetails(customerId, mobileNo, billMonth);
		return new ModelAndView("monthlyBillPage", "bill", bill);
	}
	
	@RequestMapping("/customerDetailsService")
	public ModelAndView getCustomerDetails(@SessionAttribute("customerId") int customerId) throws CustomerDetailsNotFoundException {
		Customer customer = services.getCustomerDetails(customerId);
		return new ModelAndView("customerDetailsPage", "customer", customer);
	}
	
	//Done
	@RequestMapping("/allAccountDetailsService")
	public ModelAndView getCustomerDetails(@SessionAttribute("customerId") int customerId, @RequestParam long mobileNo) throws CustomerDetailsNotFoundException {
		List<PostpaidAccount> postpaidAccounts = services.getCustomerAllPostpaidAccountsDetails(customerId);
		return new ModelAndView("customerDetailsPage", "postpaidAccounts", postpaidAccounts);
	}

	@RequestMapping("/allBillDetailsPageService")
	public ModelAndView allBillDetailsPage(@SessionAttribute("customerId") int customerId, @RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		List<Bill> bills = services.getCustomerPostPaidAccountAllBillDetails(customerId, mobileNo);
		return new ModelAndView("allBillDetailsPage", "bills", bills);
	}
	
	@RequestMapping("/changePlanService")
	public ModelAndView changePlan(@SessionAttribute("customerId") int customerId, @RequestParam long mobileNo, @RequestParam int planId) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		services.changePlan(customerId, mobileNo, planId);
		return new ModelAndView("monthlyBillPage", "done", "Plan Changed successfully to: " + planId);
	}
	
	//Done
	@RequestMapping("/closeAccountService")
	public ModelAndView closeAccount(@SessionAttribute("customerId") int customerId, @RequestParam long mobileNo) throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		services.closeCustomerPostPaidAccount(customerId, mobileNo);
		return new ModelAndView("closeAccountPage", "flag", "Your Acount linked with" + mobileNo + "is successfully deleted");
	}
}
