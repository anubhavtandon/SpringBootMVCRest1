package com.cg.billing.daoservices;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.billing.beans.PostpaidAccount;

public interface PostpaidAccountDAO  extends JpaRepository<PostpaidAccount, Long>{
	@Query("from PostpaidAccount a where a.customer.customerID=:customerId and a.mobileNo=:mobileNo")
	PostpaidAccount findOne(@Param("customerId") int customerId, @Param("mobileNo") long mobileNo);
	
	@Query(value="from PostpaidAccount a where a.customer.customerID=:customerId")
	List<PostpaidAccount> findAll(@Param("customerId") int customerId);
	
	//Pending
	@Query("delete from PostpaidAccount p where p.mobileNo=:mobileNo")
	boolean delete(@Param("mobileNo") long mobileNo);
}
