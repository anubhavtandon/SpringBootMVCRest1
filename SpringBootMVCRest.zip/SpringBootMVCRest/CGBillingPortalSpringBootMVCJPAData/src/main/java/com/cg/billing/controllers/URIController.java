package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.cg.billing.beans.Customer;

@Controller

public class URIController {
	
	private Customer customer;
	
	@RequestMapping(value= {"/","/index"})
	public String getIndexPage() {
		return "indexPage";
	}
	
	@RequestMapping("/login")
	public String getLoginPage() {
		return "loginPage";
	}
	
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "registerPage";
	}
	
	@RequestMapping("/openAccount")
	public String getOpenAccountPage() {
		return "openAccountPage";
	}
	
	@RequestMapping("/monthlyBill")
	public String getmonthlyBillPage() {
		return "monthlyBillPage";
	}
	
	@RequestMapping("/changePlanPage")
	public String getchangePlanPage() {
		return "changePlanPage";
	}
	
	@RequestMapping("/allBillDetailsPage")
	public String getAllBillDetailsPage() {
		return "allBillDetailsPage";
	}
	
	@RequestMapping("/closeAccountPage")
	public String getcloseAccountPage() {
		return "closeAccountPage";
	}
	@RequestMapping("/allAccountDetailsPage")
	public String getallAccountDetailsPage() {
		return "allAccountDetailsService";
	}
	
	
	@ModelAttribute
	public Customer getCustomer() {
		customer = new Customer();
		return customer;
	}
	
}
