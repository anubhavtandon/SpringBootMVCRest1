package com.cg.billing.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
@SessionAttributes("customerId")
public class LoginController {
	
	@Autowired
	private BillingServices services;

	@RequestMapping("/loginService")
	public ModelAndView loginUser(@RequestParam String customerID, @RequestParam String password, ModelMap model) throws CustomerDetailsNotFoundException { 
		Object userObj =  services.checkCredentials(customerID, password);
		if(userObj instanceof Customer) {
			model.put("customerId", ((Customer) userObj).getCustomerID());
			return new ModelAndView("customerHomePage");
		}
		return new ModelAndView("adminPage");
	}
}
