package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component("bankingServices")
public class BankingServicesImpl implements BankingServices {
	Account account=new Account();
	@Autowired
	AccountDAO accDAOServices;// = new AccountDAOImpl();
	@Autowired	
	TransactionDAO transDAOServices;// = new TransactionDAOImpl();

	@Override
	public Account openAccount(Account account)
			throws InvalidAccountTypeException, InvalidAmountException, BankingServicesDownException {

		if(account.getAccountType().equals("current") || account.getAccountType().equals("savings")) {

			//Account account=new Account(accountType, initBalance);

			int pinNumber=(int)(Math.random()*9999+1000);
			account.setPinNumber(pinNumber);
			account.setAccountStatus("active");
			account = accDAOServices.save(account);
			account.getTransactions().add(transDAOServices.save(new Transaction(account, account.getAccountBalanace(), "credited")));
			return account;
		}
		throw new InvalidAccountTypeException("Account type is invalid");
	}


	@Override 
	public Account depositAmount(long accountNo, float amount) throws
	AccountNotFoundException, BankingServicesDownException,
	AccountBlockedException {

		Account account = this.getAccountDetails(accountNo);
		if(account.getAccountStatus().equals("blocked")) throw new
		AccountBlockedException("Your account is blocked");
		account.setAccountBalanace(account.getAccountBalanace() + amount);
		accDAOServices.save(account); Transaction transaction =
				transDAOServices.save(new Transaction(account, amount, "credited"));
		if(account == null || transaction == null) throw new
		BankingServicesDownException("Bank servers down"); 
		else 
			return account; }

	@Override
	public Account withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {

		Account account = this.getAccountDetails(accountNo);
		if(!account.getAccountStatus().equals("blocked"))
			if(pinNumber == account.getPinNumber())
				if(account.getAccountBalanace() - amount > 0) {
					account.setAccountBalanace(account.getAccountBalanace() - amount);	
					accDAOServices.save(account);
					transDAOServices.save(new Transaction(account, amount, "debited"));
					return account;
				}
				else
					throw new InsufficientAmountException("insufficient amount");
			else
				throw new InvalidPinNumberException("Invalid Pin");
		else
			throw new AccountBlockedException("Account blocked");
	}

	@Override
	public Account fundTransfer(long accountNoFrom, long accountNoTo,
			float transferAmount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException {
		 Account account=this.withdrawAmount(accountNoFrom, transferAmount, pinNumber);
		 this.depositAmount(accountNoTo, transferAmount);
		return account;
		}


	@Override
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account = accDAOServices.findById(accountNo).orElseThrow(()->new AccountNotFoundException("Accc not found"+accountNo));
		return account;
	}

	
	  @Override public List<Account> getAllAccountDetails() throws
	  BankingServicesDownException{
		  return accDAOServices.findAll();
		  }
	  
	  @Override public List<Transaction> getAccountAllTransaction(long accountNo)
	  throws BankingServicesDownException, AccountNotFoundException { return
	  transDAOServices.findAll(); }
	  
	/*
	 * @Override public Account accountStatus(long accountNo) throws
	 * BankingServicesDownException, AccountNotFoundException,
	 * AccountBlockedException { return
	 * getAccountDetails(accountNo).getAccountStatus(); }
	 */
	 
}
