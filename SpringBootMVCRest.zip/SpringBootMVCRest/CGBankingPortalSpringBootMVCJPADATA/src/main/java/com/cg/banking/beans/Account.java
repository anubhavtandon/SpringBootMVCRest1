package com.cg.banking.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotEmpty;

@Entity
public class Account {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNo;

	private int pinNumber;
	@NotEmpty
	private String accountType;
	@NotEmpty
	private String accountStatus;
	private float accountBalanace;
	
	@OneToMany(mappedBy="account")
	public List<Transaction>transactions = new ArrayList<Transaction>(0);

	public Account() {}
	/* public Account(long accountNo) {} */
	
	
	public Account(int pinNumber, String accountType, String accountStatus, float accountBalanace) {
		super();
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBalanace = accountBalanace;
	}



	public Account(String accountType, float accountBalanace) {
		super();
		this.accountType = accountType;
		this.accountBalanace = accountBalanace;
	}
	
	public Account(String accountType, String accountStatus, float accountBalanace, List<Transaction> transactions) {
		super();
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBalanace = accountBalanace;
		this.transactions = transactions;
	}
	
	public Account(long accountNo, int pinNumber, String accountType, String accountStatus, float accountBalanace,
			List<Transaction> transactions) {
		super();
		this.accountNo = accountNo;
		this.pinNumber = pinNumber;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBalanace = accountBalanace;
		this.transactions = transactions;
	}
	

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public int getPinNumber() {
		return pinNumber;
	}

	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}

	public float getAccountBalanace() {
		return accountBalanace;
	}

	public void setAccountBalanace(float accountBalanace) {
		this.accountBalanace = accountBalanace;
	}

	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public List<Transaction> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", pinNumber=" + pinNumber + ", accountType=" + accountType
				+ ", accountStatus=" + accountStatus + ", accountBalanace=" + accountBalanace + ", transactions="
				+ transactions + "]";
	}
}