package com.cg.banking.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	Account account= new Account();
	@Autowired
	BankingServices bankingServices;
	@RequestMapping("/registerAccount")
	public ModelAndView registerAssociate(@ModelAttribute Account account) throws AccountNotFoundException, BankingServicesDownException, InvalidAccountTypeException, InvalidAmountException {
		account=bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage","account",account);
	}
	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetails(@RequestParam long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		Account account=bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("findAccountDetailsPage","account",account);
	}
	@RequestMapping("/depositedAmount")
	public ModelAndView getdepositAmount(@RequestParam long accountNo, float amount) throws AccountNotFoundException,
	BankingServicesDownException, AccountBlockedException{
		Account account=bankingServices.depositAmount(accountNo,amount);
		return new ModelAndView("depositAmountPage","account",account);
	}
	@RequestMapping("/withdrawlAmount")
	public ModelAndView getwithdrawAmount(@RequestParam long accountNo, float amount, int pinNumber )throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException  {
		Account account=bankingServices.withdrawAmount(accountNo,amount,pinNumber);
		return new ModelAndView("withdrawAmountPage","account",account);}

	@RequestMapping("/transferFundAmount")
	public ModelAndView getfundTransfer (@RequestParam long accountNoTo, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException {
		Account account=bankingServices.fundTransfer(accountNoTo,accountNoFrom,transferAmount, pinNumber);
		return new ModelAndView("fundTransferPage","account",account);
	}
@RequestMapping("/allAccountDetails")
public ModelAndView getAllAccountDetails() throws BankingServicesDownException {
	List<Account> accounts=bankingServices.getAllAccountDetails();
	return new ModelAndView("GetAllAccountDetails","accounts",accounts);

}
@RequestMapping("/allTransactionDetails")
public ModelAndView getAllTransactions(long accountNo) throws BankingServicesDownException, AccountNotFoundException {
	List<Transaction> transactions=bankingServices.getAccountAllTransaction(accountNo);
	return new ModelAndView("getTransactionPage","transactions",transactions);
}

}
