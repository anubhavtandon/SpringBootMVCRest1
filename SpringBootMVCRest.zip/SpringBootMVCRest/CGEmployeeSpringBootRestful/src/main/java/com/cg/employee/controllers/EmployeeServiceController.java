package com.cg.employee.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
import com.cg.employee.services.EmployeeServices;

@Controller
public class EmployeeServiceController {
	@Autowired
	EmployeeServices employeeServices;
	@RequestMapping(value= {"/getEmployeeDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Employee>getEmployeeDetails(@RequestParam int employeeId)throws EmployeeDetailsNotFoundException{
		Employee employee=employeeServices.getEmployeeDetails(employeeId);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	@RequestMapping(value= {"/getEmployeeDetails/{employeeId}"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<Employee>getAssociateDetailsRequestParam(@PathVariable(value="employeeId") int employeeId)throws EmployeeDetailsNotFoundException{
		Employee employee=employeeServices.getEmployeeDetails(employeeId);
		return new ResponseEntity<Employee>(employee,HttpStatus.OK);
	}
	@RequestMapping(value= {"/getAllEmployeeDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json")
	public ResponseEntity<List<Employee>>getEmployeeDetailsPathParam(){
		return new ResponseEntity<List<Employee>>(employeeServices.getAllEmployeeDetails(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/acceptEmployeeDetails"},method=RequestMethod.POST,
			produces=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>acceptEmployeeDetails(@ModelAttribute Employee employee) throws EmployeeDetailsNotFoundException{
		employee=employeeServices.acceptEmployeeDetails(employee);
		return new ResponseEntity<>("Employee Details successfully added employee Id:-"+employee.getEmployeeId(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/removeEmployeeDetails"},method=RequestMethod.DELETE,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>removeEmployeeDetails(@RequestParam int employeeId) throws EmployeeDetailsNotFoundException{
		employeeServices.removeEmoloyeeDetails(employeeId);
		return new ResponseEntity<>("Employee Details successfully removed:-"+employeeId,HttpStatus.OK);
	}
}