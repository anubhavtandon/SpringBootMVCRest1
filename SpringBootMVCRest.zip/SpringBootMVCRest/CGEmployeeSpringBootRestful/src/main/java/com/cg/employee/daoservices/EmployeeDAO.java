package com.cg.employee.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.employee.beans.Employee;

public interface EmployeeDAO extends JpaRepository<Employee, Integer> {

}
