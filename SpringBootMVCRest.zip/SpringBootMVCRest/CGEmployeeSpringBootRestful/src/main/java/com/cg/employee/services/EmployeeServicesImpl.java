package com.cg.employee.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.employee.beans.Employee;
import com.cg.employee.daoservices.EmployeeDAO;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;
@Component("employeeServices")
public class EmployeeServicesImpl implements EmployeeServices {
private Employee employee;
@Autowired
private EmployeeDAO employeeDAO;
	@Override
	public Employee acceptEmployeeDetails(Employee employee) throws EmployeeDetailsNotFoundException {
		employee=employeeDAO.save(employee);
		return employee;
	}

	@Override
	public Employee getEmployeeDetails(int employeeId) throws EmployeeDetailsNotFoundException {
		return employeeDAO.findById(employeeId).orElseThrow(()-> new EmployeeDetailsNotFoundException("Employee Details Not Found For this Employee Id"+employeeId));
	}
	@Override
	public List<Employee> getAllEmployeeDetails() {
		return employeeDAO.findAll();
	}
	@Override
	public boolean removeEmoloyeeDetails(int employeeId) throws EmployeeDetailsNotFoundException {
		employeeDAO.delete(getEmployeeDetails(employeeId));
		return true;
	}

}
