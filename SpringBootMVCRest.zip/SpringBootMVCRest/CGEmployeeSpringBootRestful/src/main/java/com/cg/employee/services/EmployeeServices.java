package com.cg.employee.services;

import java.util.List;

import com.cg.employee.beans.Employee;
import com.cg.employee.exceptions.EmployeeDetailsNotFoundException;

public interface EmployeeServices {
Employee acceptEmployeeDetails(Employee employee)throws EmployeeDetailsNotFoundException;
Employee getEmployeeDetails(int employeeId) throws EmployeeDetailsNotFoundException;
List<Employee> getAllEmployeeDetails();
boolean removeEmoloyeeDetails(int employeeId) throws EmployeeDetailsNotFoundException;
}
