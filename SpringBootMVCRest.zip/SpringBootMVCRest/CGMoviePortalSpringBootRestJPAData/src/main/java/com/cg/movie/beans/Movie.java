package com.cg.movie.beans;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Movie {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int movieId;
	private String movieName;

	@OneToMany(mappedBy="movie")
	private List<Song> song; // = new ArrayList<>();

	
	
	public Movie() {
		super();
	}

	public Movie(String movieName, List<Song> song) {
		super();
		this.movieName = movieName;
		this.song = song;
	}
	
	public Movie(int movieId, String movieName, List<Song> song) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.song = song;
	}

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public List<Song> getSong() {
		return song;
	}

	public void setSong(List<Song> song) {
		this.song = song;
	}

	@Override
	public String toString() {
		return "Movie [movieId=" + movieId + ", movieName=" + movieName + ", song=" + song + "]";
	}
	
	
}
