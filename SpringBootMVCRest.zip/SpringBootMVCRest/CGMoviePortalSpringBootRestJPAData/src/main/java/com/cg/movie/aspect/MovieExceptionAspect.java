package com.cg.movie.aspect;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.cg.movie.exceptions.MovieDetailsNotfoundException;
import com.cg.movie.exceptions.SongDetailsNotfoundException;
import com.cg.movie.response.CustomResponse;

@ControllerAdvice
public class MovieExceptionAspect {

	@ExceptionHandler(MovieDetailsNotfoundException.class)
	public ResponseEntity<CustomResponse> MovieDetailsNotfoundException(Exception e){
		CustomResponse response = new CustomResponse(e.getMessage(), HttpStatus.EXPECTATION_FAILED.value());
				return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
	}
	
	@ExceptionHandler(SongDetailsNotfoundException.class)
	public ResponseEntity<CustomResponse> SongDetailsNotfoundException(Exception e){
		CustomResponse response = new CustomResponse(e.getMessage(), HttpStatus.EXPECTATION_FAILED.value());
				return new ResponseEntity<>(response, HttpStatus.EXPECTATION_FAILED);
	}
}

