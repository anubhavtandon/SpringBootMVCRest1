package com.cg.movie.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.movie.beans.Movie;
import com.cg.movie.beans.Song;
import com.cg.movie.exceptions.MovieDetailsNotfoundException;
import com.cg.movie.exceptions.SongDetailsNotfoundException;
import com.cg.movie.services.MovieServices;


@Controller
public class MovieServicesController {

	@Autowired
	MovieServices movieServices;
	
	@RequestMapping(value= {"/getMovieDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Movie> getMovieDetailsRequestParam(@RequestParam int movieId) throws MovieDetailsNotfoundException{
		Movie movie=movieServices.getMovieDetails(movieId);
		return new ResponseEntity<Movie>(movie,HttpStatus.OK);
	}
	
	
	@RequestMapping(value= {"/acceptMovieeDetails"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptMovieDetails(@ModelAttribute Movie movie){
		movie=movieServices.acceptMovieDetails(movie);
		return new ResponseEntity<>("Associate details added successfully"+movie.getMovieId(),HttpStatus.OK);
	}
//	
//	@RequestMapping(value= {"/acceptProductDetails"},method=RequestMethod.POST,
//			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
//	public ResponseEntity<String> acceptAssociateDetails(@ModelAttribute Associate associate){
//		associate=payrollServices.acceptAssociateDetails(associate);
//		return new ResponseEntity<>("Associate details added successfully"+associate.getAssociateId(),HttpStatus.OK);
//	}
//	
	
	
	@RequestMapping(value= {"/getSongDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE, headers="Accept=application/json")
	public ResponseEntity<Song> getSongDetailsRequestParam(@RequestParam int songId) throws SongDetailsNotfoundException{
		Song song=movieServices.getSongDetails(songId);
		return new ResponseEntity<Song>(song,HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/acceptSonggDetails"},method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String> acceptSongDetailsRequestParam(@ModelAttribute Song song){
		song=movieServices.acceptSongDetails(song);
		return new ResponseEntity<>("Associate details added successfully"+song.getSongId(),HttpStatus.OK);
	}	
	
	
	@RequestMapping(value= {"/getAllSongDetails"},method=RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Song>> getAssociateDetailsPathParam(@RequestParam int movieId){
		List<Song> songs=movieServices.getAllSongDetails(movieId);
		return new ResponseEntity<List<Song>>(songs,HttpStatus.OK);
	}
}